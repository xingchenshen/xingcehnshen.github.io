[![996.icu](https://img.shields.io/badge/link-996.icu-red.svg)](https://996.icu) [![LICENSE](https://img.shields.io/badge/license-Anti%20996-blue.svg)](https://github.com/996icu/996.ICU/blob/master/LICENSE)

**撒娇打滚求star哦\~\~ ღ( ´･ᴗ･\` )比心**
# 扫雷主界面模块

![扫雷主界面模块主要功能](https://img-blog.csdnimg.cn/20181225155346207.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

整个扫雷界面使用大量的白色方格（正方形）进行显示，本游戏软件刚刚运行时刻， 游戏界面的完整显示图如下图所示：

![游戏界面的完整显示图](https://img-blog.csdnimg.cn/20181225155410897.png)

玩家可以使用鼠标左键随机点击一个方格，方格即被打开并显示出方格中的数字，方格中数字则表示其周围的方格中（最多8个）隐藏了几颗雷，在上图的情况下左键点击一个方格后的显示图如下图所示：

![左键点击一个方格后的显示图](https://img-blog.csdnimg.cn/20181225155430589.png)

如果点开的格子为空白格，即其周围有0颗雷，则其周围格子自动打开，如果其周围还有空白格，则会继续打开并引发连锁反应，在上图情况下点击一个空白格后的显示图如下图所示：

![点击一个空白格后的显示图](https://img-blog.csdnimg.cn/20181225155501954.png)

玩家可以在认为有雷的格子上点击右键，方格上将显示一个小红旗图像，即表示标记此地区为雷区，在上图情况下点击右键的显示图如下图所示：

![显示图](https://img-blog.csdnimg.cn/20181225155615773.png)

再次点击右键，方格上将显示一个问号图像，表示不确定此方格是否有雷，在在上图情况下点击右键的显示图如下图所示：

![显示图](https://img-blog.csdnimg.cn/20181225155634796.png)

第三次点击右键，格子将恢复正常，在上图情况下点击右键的显示图如下图所示：

![显示图](https://img-blog.csdnimg.cn/20181225155708252.png)

如果一个已打开格子周围所有的雷已经正确标出，则可以在此格上同时点击鼠标左右键以打开其周围剩余的无雷格，在上图情况下点击右键的显示图如下图所示：

![显示图](https://img-blog.csdnimg.cn/20181225155723349.png)

游戏结束时，主界面将用绿色的对号表示标记正确的雷区，用红色的叉号表示标记错误的雷区，用黑色的炸药图像标记没有标记的雷区。
当排出所有的雷区后，游戏胜利，某一时刻游戏胜利的游戏界面如下图所示：

![某一时刻游戏胜利的游戏界面](https://img-blog.csdnimg.cn/20181225155812893.png)

如果游戏胜利时用时低于扫雷英雄榜中相应级别的记录，将跳出一个对话框提示用户可以输入自己名字以刷新扫雷英雄榜中记录，跳出的对话框显示图如下图所示：

![跳出的对话框](https://img-blog.csdnimg.cn/20181225155859469.png)

当左键点击到雷区时，游戏失败，某一时刻游戏失败的游戏界面如下图所示：

![某一时刻游戏失败的游戏界面](https://img-blog.csdnimg.cn/20181225155915590.png)

# 菜单功能模块

![菜单功能模块主要功能](https://img-blog.csdnimg.cn/20181225155934250.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

![菜单功能模块游戏菜单栏显示图](https://img-blog.csdnimg.cn/20181225155949501.png)

![菜单功能模块帮助菜单栏显示图](https://img-blog.csdnimg.cn/20181225160006989.png)

![游戏规则界面显示图](https://img-blog.csdnimg.cn/20181225160052172.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

![符号说明界面显示图](https://img-blog.csdnimg.cn/20181225160101646.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

![自定义参数上下限界面显示图](https://img-blog.csdnimg.cn/20181225160035540.png)
