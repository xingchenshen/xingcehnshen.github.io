# 注意
**本软件使用了许多图片以及一首背景音乐，这些图片和背景音乐均需放入media文件夹下，media文件夹需要与代码文件放在一起，用到的诸多图片及其命名罗列如下，至于背景音乐，由于github无法上传mp3文件，就自己去网上搜一首自己喜欢的，命名为“background.mp3”即可**
## correct.jpg

![correct.jpg](https://img-blog.csdnimg.cn/20181225161914852.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

## mistake.jpg

![mistake.jpg](https://img-blog.csdnimg.cn/20181225162141649.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

## question.jpg

![question.jpg](https://img-blog.csdnimg.cn/20181225162202299.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

## mine.jpg

![mine.jpg](https://img-blog.csdnimg.cn/2018122516221284.jpg)

## flag.jpg

![flag.jpg](https://img-blog.csdnimg.cn/20181225162238506.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3JpY2hlbnl1bnFp,size_16,color_FFFFFF,t_70)

## fail.png

![fail.png](https://img-blog.csdnimg.cn/20181225162248762.png)

## win.png

![win.png](https://img-blog.csdnimg.cn/20181225162303681.png)

## underway.png

![underway.png](https://img-blog.csdnimg.cn/20181225162313619.png)
